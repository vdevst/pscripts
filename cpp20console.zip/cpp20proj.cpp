void foo(int)
{}

int main()
{
    signed int x{ 5 };
    foo(x);

    return 0;
}